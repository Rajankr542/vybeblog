var mongoose=require('mongoose');
var Filter_value = mongoose.model('Filter_value', { filter_value: String});
module.exports =Filter_value;
